// Cloudflare Pages Functions - SPA 路由兜底
// 所有非静态资源请求都返回 index.html，交由 React Router 处理
export async function onRequest(context) {
  const { request, next, env } = context;
  const url = new URL(request.url);
  const path = url.pathname;

  // 静态资源直接放行
  if (
    path.startsWith('/assets/') ||
    path.startsWith('/favicon.') ||
    path.startsWith('/icons.') ||
    path === '/robots.txt' ||
    path === '/sitemap.xml' ||
    path === '/_routes.json' ||
    path.includes('.')
  ) {
    return next();
  }

  // API 路径（预留）
  if (path.startsWith('/api/')) {
    return next();
  }

  // 其余路径返回 index.html (SPA)
  const assetUrl = new URL('/index.html', url.origin);
  const res = await env.ASSETS.fetch(assetUrl.toString());
  return new Response(res.body, {
    status: res.status,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'public, max-age=0, must-revalidate',
    },
  });
}
