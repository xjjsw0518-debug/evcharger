// prerender.mjs — 构建后预渲染脚本
// 用法：node prerender.mjs
// 功能：启动本地静态服务 → Puppeteer 访问各路由 → 保存渲染后的 HTML → 生成 sitemap.xml + robots.txt

import path from 'node:path';
import fs from 'node:fs';
import http from 'node:http';
import { fileURLToPath } from 'node:url';
import { Prerenderer } from '@prerenderer/prerenderer';
import PuppeteerRenderer from '@prerenderer/renderer-puppeteer';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST_DIR = path.join(__dirname, 'dist');

// 后台管理路径（与 src/app.tsx 中的默认值保持一致）
const ADMIN_PATH = 'XUEJIAN-manage';

// 预渲染的路由
const PRERENDER_ROUTES = [
  '/',
  '/products',
  '/about',
  '/contact',
  '/blog',
  '/faq',
  '/404',
  // EV 充电配件产品分类页
  '/products/charging-guns',
  '/products/adapters',
  '/products/portable-chargers',
  '/products/cables',
  '/products/sockets-connectors',
  '/products/v2l-discharge',
  '/products/accessories',
  // EV charging accessory product pages (all 12)
  '/products/ev-gbt-32a-7kw-gun',
  '/products/ev-gbt-to-type2-adapter',
  '/products/ev-type2-to-gbt-adapter',
  '/products/ev-portable-charger-7kw-byd',
  '/products/ev-gbt-gun-only-no-cable',
  '/products/ev-gbt-charging-cable',
  '/products/ev-gbt-ac-socket-vehicle',
  '/products/ev-charging-gun-lock-kit',
  '/products/ev-waterproof-connector-harness',
  '/products/ev-v2l-discharge-adapter-byd',
  '/products/ev-portable-charger-7kw-lcd',
  '/products/ev-cable-organizer-wall-mount',
  // Blog posts (EV charging themed)
  '/blog/blog-001',
  '/blog/blog-002',
  '/blog/blog-003',
  '/blog/blog-004',
  '/blog/blog-005',
  '/blog/blog-006',
  '/blog/blog-007',
  '/blog/blog-008',
  '/blog/blog-009',
  '/blog/blog-010',
  '/blog/blog-011',
  '/blog/blog-012',
];

// 站点 URL（用于 sitemap）
const SITE_URL = 'https://youpei-auto.example.com';

// 启动简易静态服务器
function startStaticServer(root, port) {
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.svg': 'image/svg+xml',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.map': 'application/json; charset=utf-8',
  };

  const server = http.createServer((req, res) => {
    let filePath = path.join(root, req.url.split('?')[0]);
    if (filePath.endsWith('/')) {
      filePath = path.join(filePath, 'index.html');
    }
    if (!fs.existsSync(filePath)) {
      filePath = path.join(root, 'index.html');
    }
    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes[ext] || 'application/octet-stream';
    try {
      const content = fs.readFileSync(filePath);
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    } catch {
      res.writeHead(500);
      res.end('Server error');
    }
  });

  return new Promise((resolve) => {
    server.listen(port, () => resolve(server));
  });
}

// 生成 sitemap.xml
function generateSitemap(routes, distDir) {
  const urls = routes
    .filter(route => route !== '/404') // 404 页不进 sitemap
    .map((route) => {
      const lastmod = new Date().toISOString().split('T')[0];
      const isHome = route === '/';
      const isProduct = route.startsWith('/products/') && route.split('/').length === 3 && !isCategoryRoute(route);
      const isCategory = isCategoryRoute(route);
      const priority = isHome ? '1.0' : isProduct ? '0.9' : isCategory ? '0.85' : '0.8';
      const changefreq = isProduct ? 'weekly' : isCategory ? 'weekly' : 'monthly';
      return `  <url>
    <loc>${SITE_URL}${route}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>${changefreq}</changefreq>
    <priority>${priority}</priority>
  </url>`;
    })
    .join('\n');

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls}
</urlset>
`;
  fs.writeFileSync(path.join(distDir, 'sitemap.xml'), sitemap, 'utf-8');
  console.log(`[prerender] sitemap.xml 已生成 (${routes.filter(r => r !== '/404').length} URLs)`);
}

function isCategoryRoute(route) {
  const categoryIds = [
    'charging-guns', 'adapters', 'portable-chargers', 'cables',
    'sockets-connectors', 'v2l-discharge', 'accessories',
  ];
  return categoryIds.some(id => route === `/products/${id}`);
}

// 生成 robots.txt
function generateRobots(distDir) {
  const content = `User-agent: *
Allow: /
Disallow: /${ADMIN_PATH}
Disallow: /${ADMIN_PATH}/login
Disallow: /api

Sitemap: ${SITE_URL}/sitemap.xml

Crawl-delay: 1
`;
  fs.writeFileSync(path.join(distDir, 'robots.txt'), content, 'utf-8');
  console.log('[prerender] robots.txt 已生成');
}

// 主流程
async function main() {
  if (!fs.existsSync(DIST_DIR)) {
    console.error('[prerender] 错误：dist 目录不存在，请先执行 npm run build');
    process.exit(1);
  }

  const port = 8765;
  console.log(`[prerender] 启动静态服务器端口 ${port}...`);
  const server = await startStaticServer(DIST_DIR, port);

  try {
    const prerenderer = new Prerenderer();

    console.log('[prerender] 初始化 Puppeteer...');
    await prerenderer.initialize({
      staticDir: DIST_DIR,
      server: { port },
      renderer: new PuppeteerRenderer({
        renderAfterElementExists: '#root > *',
        renderAfterTime: 3000,
        maxConcurrentRoutes: 4,
        skipThirdPartyRequests: true,
        launchOptions: {
          headless: true,
          args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-gpu',
          ],
        },
      }),
    });

    console.log(`[prerender] 开始预渲染 ${PRERENDER_ROUTES.length} 个路由...`);
    const rendered = await prerenderer.renderRoutes(PRERENDER_ROUTES);

    for (const route of rendered) {
      const routePath = route.originalRoute || route.route;
      let outputPath;
      if (routePath === '/' || routePath === '') {
        outputPath = path.join(DIST_DIR, 'index.html');
      } else if (routePath === '/404') {
        outputPath = path.join(DIST_DIR, '404.html');
      } else if (routePath.endsWith('.html')) {
        outputPath = path.join(DIST_DIR, routePath);
      } else {
        const cleanPath = routePath.replace(/^\//, '');
        outputPath = path.join(DIST_DIR, cleanPath, 'index.html');
      }

      const dir = path.dirname(outputPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      fs.writeFileSync(outputPath, route.html, 'utf-8');
      console.log(`[prerender] ✓ ${routePath} → ${path.relative(DIST_DIR, outputPath)}`);
    }

    console.log('[prerender] 预渲染完成！');
    generateSitemap(PRERENDER_ROUTES, DIST_DIR);
    generateRobots(DIST_DIR);

    await prerenderer.destroy();
  } catch (err) {
    console.error('[prerender] 预渲染失败：', err);
    process.exit(1);
  } finally {
    server.close();
  }
}

main();
